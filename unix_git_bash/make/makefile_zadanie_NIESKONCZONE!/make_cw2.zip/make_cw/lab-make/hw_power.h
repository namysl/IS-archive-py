/** @file hw_power.h
  * Plik nag��wkowy funkcji wypisuj�cych wyniki operacji mat
  * $Id$
  */

#ifndef HW_POWER_H
#define HW_POWER_H

int calc_pow3 (int n);

#endif
