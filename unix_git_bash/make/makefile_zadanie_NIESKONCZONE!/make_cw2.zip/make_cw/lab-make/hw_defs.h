/** @file hw_defs.h
  * G��wny plik nag��wkowy programu
  * $Id$
  */

#ifndef HW_DEFS_H
#define HW_DEFS_H

/* zak�adamy, ze mo�na to poda� przy kompilacji */
#ifndef WERSJA
#define WERSJA 1 /**< wersja kodu */
#endif

#endif
